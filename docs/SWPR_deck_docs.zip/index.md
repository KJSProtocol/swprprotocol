# SWPR — Dust Recovery Value Protocol

Deck homepage

- [1. Introduction](01-intro.md)
- [2. Problem & Market](02-problem.md)
- [3. Architecture](03-solution-architecture.md)
- [4. Tokenomics](04-tokenomics.md)
- [5. Advantages](05-advantages.md)
- [6. Technical](06-technical.md)
- [7. Roadmap](07-roadmap.md)
- [8. Appendix](08-appendix.md)
